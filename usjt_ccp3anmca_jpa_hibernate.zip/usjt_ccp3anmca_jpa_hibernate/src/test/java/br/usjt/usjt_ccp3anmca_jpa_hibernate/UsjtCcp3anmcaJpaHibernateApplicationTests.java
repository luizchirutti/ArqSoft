package br.usjt.usjt_ccp3anmca_jpa_hibernate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UsjtCcp3anmcaJpaHibernateApplicationTests {

	@Test
	public void contextLoads() {
	}

}
